﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.Foundation;
using Windows.Phone.UI.Input;
using System.Threading.Tasks;
using Windows.UI.Xaml.Shapes;
using Windows.UI;
using Windows.UI.Xaml.Media;
using Windows.Devices.Enumeration;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace BlueBox
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BlueBoxesPage : Page
    {
        Guid ConnectedCarServiceGUID = new Guid("0000cc01-0000-1000-8000-00805f9b34fb");
        //Guid ConnectedCarServiceGUID = new Guid("d08d68af-6053-781a-d3b8-05fd010ac533");

        DeviceInformationCollection foundDevices = null; 
        public BlueBoxesPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            foundDevices = await DeviceInformation.FindAllAsync(GattDeviceService.GetDeviceSelectorFromUuid(ConnectedCarServiceGUID));
            int device_count = foundDevices.Count;
            Debug.WriteLine(device_count);  
              
            for (int i = 0; i < foundDevices.Count; i++)
            {
                DeviceInformation deviceInfo = foundDevices[i]; deviceList.Items.Add(deviceInfo.Name);
            }
        }

        private void SelectedDevice(object sender, SelectionChangedEventArgs e)
        {
            var lv = sender as ListView; 
            if (lv != null) 
            { 
                if (lv.SelectedIndex >= 0 && lv.SelectedIndex < foundDevices.Count) 
                { 
                    DeviceInformation devInfo = foundDevices[lv.SelectedIndex]; 
                    this.Frame.Navigate(typeof(LoginPage), devInfo.Id);
                } 
            }   
        }
    }
}
