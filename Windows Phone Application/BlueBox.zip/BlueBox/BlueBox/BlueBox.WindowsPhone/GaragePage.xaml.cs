﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage.Streams;
using Windows.UI;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace BlueBox
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class GaragePage : Page
    {
        Guid ConnectedCarServiceGUID = new Guid("0000cc01-0000-1000-8000-00805f9b34fb");
        Guid GarageCharacteristicGUID = new Guid("0000cc07-0000-1000-8000-00805f9b34fb");

        GattDeviceService garage_service;
        BluetoothLEDevice mDevice = null;

        String deviceId;
        private static int stateG;
        public GaragePage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            deviceId = e.Parameter.ToString();
            mDevice = await BluetoothLEDevice.FromIdAsync(deviceId);
            if (mDevice != null)
            {
                // update connect text in the UI        
                if (mDevice.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                {
                    Debug.WriteLine("GATT service has been disconntected....");
                }
                initialiseGattResources();
                ChangeState(stateG);
            }
        }      

        private void BtnBack(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MenuPage),deviceId);
        }

        private async void BtnClose(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (garage_service != null)
            {
                var characteristic = garage_service.GetCharacteristics(GarageCharacteristicGUID)[0];
                if (characteristic != null)
                {
                    // create a data writer to write the value  
                    DataWriter writer = new DataWriter();
                    writer.WriteByte(3);
                    // Attempt to write the data to the device           
                    GattCommunicationStatus status = await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                    if (status == GattCommunicationStatus.Success)
                    {
                        GattReadResult readValue = await characteristic.ReadValueAsync();
                        stateG = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte(); 
                        Debug.WriteLine("set");
                        ChangeState(stateG);
                    }
                    else
                    {
                        Debug.WriteLine("not set");
                    }
                }
                else 
                {
                    Debug.WriteLine("charactertisics unavilable");
                    //commment out when working
                    message.Text = "Connection issue with the characteristic";
                }
            }
            else 
            {
                Debug.WriteLine("service unavilable");
                //commment out when working
                message.Text = "Connection issue with the service";
            }
        }

        private async void BtnOpen(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (garage_service != null)
            {
                var characteristic = garage_service.GetCharacteristics(GarageCharacteristicGUID)[0];
                if (characteristic != null)
                {
                    // create a data writer to write the value  
                    DataWriter writer = new DataWriter();
                    writer.WriteByte(2);
                    // Attempt to write the data to the device           
                    GattCommunicationStatus status = await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                    if (status == GattCommunicationStatus.Success)
                    {
                        GattReadResult readValue = await characteristic.ReadValueAsync();
                        stateG = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte(); 
                        Debug.WriteLine("set");
                        ChangeState(stateG);
                    }
                    else
                    {
                        Debug.WriteLine("not set");
                    }
                }
                else
                {
                    Debug.WriteLine("charactertisics unavilable");
                    //commment out when working
                    message.Text = "Connection issue with the characteristic";
                }
            }
            else 
            {
                Debug.WriteLine("service unavilable");
                //commment out when working
                message.Text = "Connection issue with the service";
            }
        }

        private async void BtnStop(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (garage_service != null)
            {
                var characteristic = garage_service.GetCharacteristics(GarageCharacteristicGUID)[0];
                if (characteristic != null)
                {
                    // create a data writer to write the value  
                    DataWriter writer = new DataWriter();
                    writer.WriteByte(1);
                    // Attempt to write the data to the device           
                    GattCommunicationStatus status = await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                    if (status == GattCommunicationStatus.Success)
                    {
                        GattReadResult readValue = await characteristic.ReadValueAsync();
                        stateG = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte(); 
                        Debug.WriteLine("set");
                        ChangeState(stateG);
                    }
                    else
                    {
                        Debug.WriteLine("not set");
                    }
                }
                else
                {
                    Debug.WriteLine("charactertisics unavilable");
                    //commment out when working
                    message.Text = "Connection issue with the characteristic";
                }
            }
            else
            {
                Debug.WriteLine("service unavilable");
                //commment out when working
                message.Text = "Connection issue with the service";
            }
        }
        private async void initialiseGattResources()
        {
            // hook up the connection status change callback             
            mDevice.ConnectionStatusChanged += ConnectionChanged;
            // get the service             
            garage_service = mDevice.GetGattService(ConnectedCarServiceGUID);
            GattCharacteristic characteristic = garage_service.GetCharacteristics(GarageCharacteristicGUID)[0];
            if (characteristic != null)
            {
                // read its current value                      
                GattReadResult readValue = await characteristic.ReadValueAsync();
                stateG = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte();
            }  
        }

        async void ConnectionChanged(BluetoothLEDevice device, object obj)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.High, () =>
            {
                if (device.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                    Debug.WriteLine("Conntection change to disconnected");
                else
                    Debug.WriteLine("Connection change to connected");
            });
        }

        private void ChangeState(int state)
        {
            switch (state)
            {
                case 1:
                    stop.BorderBrush = new SolidColorBrush(Colors.White);
                    stop.Background.Opacity = 0.5;
                    open.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    open.Background.Opacity = 1.0;
                    close.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    close.Background.Opacity = 1.0;
                    break;
                case 2:
                    close.BorderBrush = new SolidColorBrush(Colors.White);
                    close.Background.Opacity = 0.5;
                    stop.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    stop.Background.Opacity = 1.0;
                    open.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    open.Background.Opacity = 1.0;
                    break;
                case 3:
                    open.BorderBrush = new SolidColorBrush(Colors.White);
                    open.Background.Opacity = 0.5;
                    close.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    close.Background.Opacity = 1.0;
                    stop.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    stop.Background.Opacity = 1.0;
                    break;
            }
        }
    }
}
