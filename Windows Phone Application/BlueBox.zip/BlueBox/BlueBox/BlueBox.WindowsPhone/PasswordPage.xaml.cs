﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.UI.Core;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Diagnostics;
using Windows.Storage.Streams;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace BlueBox
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class PasswordPage : Page
    {
        Guid ConnectedCarServiceGUID = new Guid("0000cc01-0000-1000-8000-00805f9b34fb");
        Guid PasswordCharacteristicGUID = new Guid("0000cc02-0000-1000-8000-00805f9b34fb");
        Guid ResultCharacteristicGUID = new Guid("0000cc04-0000-1000-8000-00805f9b34fb");
        Guid PasswordChangeCharacteristicGUID = new Guid("0000cc03-0000-1000-8000-00805f9b34fb");
        Guid ResultChangeCharacteristicGUID = new Guid("0000cc05-0000-1000-8000-00805f9b34fb");

        GattDeviceService password_service;
        BluetoothLEDevice mDevice = null;

        String deviceId;
        private int val =1 ;
        private int valCheck;

        private String OldP, NewP, RetypeP;
        public PasswordPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            deviceId = e.Parameter.ToString();
            mDevice = await BluetoothLEDevice.FromIdAsync(deviceId);
            if (mDevice != null)
            {
                // update connect text in the UI        
                if (mDevice.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                {
                    Debug.WriteLine("GATT service has been disconntected....");
                }
                initialiseGattResources();
            }
        }

        private void BtnBack(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(SettingsPage),deviceId);
        }

        private async void BtnSave(object sender, RoutedEventArgs e)
        {
            if (OldPassword.Text.Length == 4 && NewPassword.Text.Length == 4 && RetypePassword.Text.Length == 4)
            {
                int decValue = int.Parse(OldPassword.Text.ToString());
                // Convert the hex string back to the number
                short value16 = Convert.ToInt16(decValue);
                if (password_service != null)
                {
                    // get the characteristic                 
                    var characteristic = password_service.GetCharacteristics(PasswordCharacteristicGUID)[0];
                    if (characteristic != null)
                    {
                        // create a data writer to write the value  
                        DataWriter writer = new DataWriter();
                        byte[] storingByte = BitConverter.GetBytes(value16);
                        Array.Reverse(storingByte);
                        writer.WriteBytes(storingByte);
                        // Attempt to write the data to the device           
                        GattCommunicationStatus status = await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                        if (status == GattCommunicationStatus.Success)
                        {
                            var results = password_service.GetCharacteristics(ResultCharacteristicGUID)[0];
                            if (results != null)
                            {
                                results.ValueChanged += passwordCharacteristic_ValueChanged;
                                await results.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);

                                if (val == 1)
                                {
                                    if (NewPassword.Text.ToString() == RetypePassword.Text.ToString())
                                    {
                                        // get the characteristic                  
                                        var changeCharacteristic = password_service.GetCharacteristics(PasswordChangeCharacteristicGUID)[0];
                                        if (changeCharacteristic != null)
                                        {
                                            int decValueTwo = int.Parse(NewPassword.Text.ToString());
                                            // Convert the hex string back to the number
                                            short value16Two = Convert.ToInt16(decValueTwo);
                                            // create a data writer to write the value                    
                                            DataWriter changeWriter = new DataWriter();
                                            byte[] changeStoringByte = BitConverter.GetBytes(value16Two);
                                            Array.Reverse(changeStoringByte);
                                            changeWriter.WriteBytes(changeStoringByte);

                                            GattCommunicationStatus changeStatus = await changeCharacteristic.WriteValueAsync(changeWriter.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                                            if (changeStatus == GattCommunicationStatus.Success)
                                            {
                                                var changeResults = password_service.GetCharacteristics(ResultChangeCharacteristicGUID)[0];
                                                if (changeResults != null)
                                                {
                                                    changeResults.ValueChanged += passwordCharacteristicCheck_ValueChanged;
                                                    await changeResults.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);
                                                    this.Frame.Navigate(typeof(MenuPage), deviceId);
                                                    
                                                }
                                                else
                                                {
                                                    Debug.WriteLine("charactertisics unavilable");
                                                    //commment out when working
                                                    message.Text = "Connection issue with the characteristic";
                                                }
                                            }
                                            else
                                            {
                                                Debug.WriteLine("unable to wrtite new pasword");
                                                //commment out when working
                                                message.Text = "Connection issue with the service";
                                            }
                                        }
                                        else
                                        {
                                            Debug.WriteLine("charactertisics unavilable");
                                            //commment out when working
                                            message.Text = "Connection issue with the password change characteristic";
                                        }
                                    }
                                    else
                                    {
                                        Debug.WriteLine("new password do not match");
                                        message.Text = "New passwords do not match";
                                    }
                                }
                                else
                                {
                                    Debug.WriteLine("Old password dot not match");
                                    message.Text = "Old passwords do not match";
                                }
                            }
                            else
                            {
                                Debug.WriteLine("charactertisics unavilable");
                                //commment out when working
                                message.Text = "Connection issue with the password change characteristic";
                            }
                        }
                        else
                        {
                            Debug.WriteLine("charactertisics unavilable");
                            //commment out when working
                            message.Text = "Connection statues unsuccesfull";
                        }

                    }
                    else 
                    {
                        Debug.WriteLine("charactertisics unavilable");
                        //commment out when working
                        message.Text = "Connection issue with the characteristic";
                    }
                }
                else 
                {
                    Debug.WriteLine("service unavilable");
                    //commment out when working
                    message.Text = "Connection issue with the service";
                }
            }
            else 
            {
                Debug.WriteLine("all passcode shoulds equal to 4 numbers");
                message.Text = "All passcode shoulds equal to 4 numbers";
            }
        }

        private void initialiseGattResources()
        {
            // hook up the connection status change callback             
            mDevice.ConnectionStatusChanged += ConnectionChanged;
            // get the service             
            password_service = mDevice.GetGattService(ConnectedCarServiceGUID);
        }

        void passwordCharacteristic_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            byte[] Data = new byte[args.CharacteristicValue.Length];
            Windows.Storage.Streams.DataReader.FromBuffer(args.CharacteristicValue).ReadBytes(Data);
            val = convertData(Data);
            Debug.WriteLine("value: " + val );
        }

        void passwordCharacteristicCheck_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            byte[] Data = new byte[args.CharacteristicValue.Length];
            Windows.Storage.Streams.DataReader.FromBuffer(args.CharacteristicValue).ReadBytes(Data);
            valCheck = convertData(Data);
            Debug.WriteLine( "check: " +valCheck);
        }

        int convertData(byte[] Data)
        {
            //The heartRateData received is a byte array with size 2. But the first position of the array is a not used flag
            //The heart rate data is in the second position of the heartRateData
            return ((int)Data[0]);
        }

        async void ConnectionChanged(BluetoothLEDevice device, object obj)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.High, () =>
            {
                if (device.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                    Debug.WriteLine("Conntection change to disconnected");
                else
                    Debug.WriteLine("Connection change to connected");
            });
        }
    }
}
