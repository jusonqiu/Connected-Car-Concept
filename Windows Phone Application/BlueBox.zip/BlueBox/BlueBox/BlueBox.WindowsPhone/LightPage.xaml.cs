﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage.Streams;
using Windows.UI;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace BlueBox
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class LightPage : Page
    {
        Guid ConnectedCarServiceGUID = new Guid("0000cc01-0000-1000-8000-00805f9b34fb");
        Guid LightsCharacteristicGUID = new Guid("0000cc06-0000-1000-8000-00805f9b34fb");

        GattDeviceService light_service;
        BluetoothLEDevice mDevice = null;

        private static int stateL;
        String deviceId;
        public LightPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            deviceId = e.Parameter.ToString();
            mDevice = await BluetoothLEDevice.FromIdAsync(deviceId);
            if (mDevice != null)
            {
                // update connect text in the UI        
                if (mDevice.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                {
                    Debug.WriteLine("GATT service has been disconntected....");
                }
                initialiseGattResources();
                ChangeState(stateL);
            }
        }

        private void BtnBack(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MenuPage),deviceId);
        }

        private async void BtnOn(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (light_service != null)
            {
                var characteristic = light_service.GetCharacteristics(LightsCharacteristicGUID)[0];
                if (characteristic != null)
                {
                    // create a data writer to write the value  
                    DataWriter writer = new DataWriter();
                    writer.WriteByte(2);
                    // Attempt to write the data to the device           
                    GattCommunicationStatus status = await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                    if (status == GattCommunicationStatus.Success)
                    {
                        Debug.WriteLine("set");
                        GattReadResult readValue = await characteristic.ReadValueAsync();
                        stateL = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte(); 
                        ChangeState(stateL);
                    }
                    else
                    {
                        Debug.WriteLine("not set");
                    }
                }
                else
                {
                    Debug.WriteLine("charactertisics unavilable");
                    //commment out when working
                    message.Text = "Connection issue with the characteristic";
                }
            }
            else
            {
                Debug.WriteLine("service unavilable");
                //commment out when working
                message.Text = "Connection issue with the service";
            }
        }

        private async void BtnOff(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (light_service != null)
            {
                var characteristic = light_service.GetCharacteristics(LightsCharacteristicGUID)[0];
                if (characteristic != null)
                {
                    // create a data writer to write the value  
                    DataWriter writer = new DataWriter();
                    writer.WriteByte(1);
                    // Attempt to write the data to the device           
                    GattCommunicationStatus status = await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                    if (status == GattCommunicationStatus.Success)
                    {
                        GattReadResult readValue = await characteristic.ReadValueAsync();
                        stateL = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte(); 
                        Debug.WriteLine("set");
                        ChangeState(stateL);
                    }
                    else
                    {
                        Debug.WriteLine("not set");
                    }
                }
                else
                {
                    Debug.WriteLine("charactertisics unavilable");
                    //commment out when working
                    message.Text = "Connection issue with the characteristic";
                }
            }
            else
            {
                Debug.WriteLine("service unavilable");
                //commment out when working
                message.Text = "Connection issue with the service";
            }
        }

        private async void initialiseGattResources()
        {
            // hook up the connection status change callback             
            mDevice.ConnectionStatusChanged += ConnectionChanged;
            // get the service             
            light_service = mDevice.GetGattService(ConnectedCarServiceGUID);
            if (light_service != null)             
            {                 
                // get the characteristic                  
                GattCharacteristic characteristic = light_service.GetCharacteristics(LightsCharacteristicGUID)[0]; 
                if (characteristic != null)                 
                {                     
                    // read its current value                      
                    GattReadResult readValue = await characteristic.ReadValueAsync();                           
                    stateL = (int)Windows.Storage.Streams.DataReader.FromBuffer(readValue.Value).ReadByte( );     
                }           
            }
        }

        async void ConnectionChanged(BluetoothLEDevice device, object obj)
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.High, () =>
            {
                if (device.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                    Debug.WriteLine("Conntection change to disconnected");
                else
                    Debug.WriteLine("Connection change to connected");
            });
        }

        private void ChangeState(int state) 
        {
            switch (state)
            { 
                case 1:
                    off.BorderBrush = new SolidColorBrush(Colors.White);
                    off.Background.Opacity = 0.5;
                    on.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    on.Background.Opacity = 1.0;
                    break;
                case 2:
                    on.BorderBrush = new SolidColorBrush(Colors.White);
                    on.Background.Opacity = 0.5;
                    off.BorderBrush = new SolidColorBrush(Colors.Transparent);
                    off.Background.Opacity = 1.0;
                    break;
            }
        }
    }
}
