﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.Foundation;
using Windows.Phone.UI.Input;
using System.Threading.Tasks;
using Windows.UI.Xaml.Shapes;
using Windows.UI;
using Windows.UI.Xaml.Media;
using System.Collections.Generic;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkID=390556

namespace BlueBox
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class LoginPage : Page
    {
        private String password = "";
        private int val;
        String deviceId;

        Guid ConnectedCarServiceGUID = new Guid("0000cc01-0000-1000-8000-00805f9b34fb");
        Guid PasswordCharacteristicGUID = new Guid("0000cc02-0000-1000-8000-00805f9b34fb");
        Guid ResultCharacteristicGUID = new Guid("0000cc04-0000-1000-8000-00805f9b34fb");

  
        GattDeviceService password_service;
        public BluetoothLEDevice mDevice = null; 
        public LoginPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.
        /// This parameter is typically used to configure the page.</param>
        protected async override void OnNavigatedTo(NavigationEventArgs e)
        {
            deviceId = e.Parameter.ToString();
            mDevice = await BluetoothLEDevice.FromIdAsync(deviceId); 
            if (mDevice != null)
            {                
                // update connect text in the UI        
                if (mDevice.ConnectionStatus == BluetoothConnectionStatus.Disconnected) 
                {
                    Debug.WriteLine("GATT service has been disconntected....");     
                }
                initialiseGattResources();
            }
      }

        private async void BtnValidate(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (password.Length == 4)
            {
                int decValue = int.Parse(password); 
                // Convert the hex string back to the number
                short value16 = Convert.ToInt16(decValue);
                if (password_service != null)            
                {                 
                    // get the characteristic                 
                    var characteristic = password_service.GetCharacteristics(PasswordCharacteristicGUID)[0];
                    if (characteristic != null)                 
                    {                    
                        // create a data writer to write the value  
                        DataWriter writer = new DataWriter();
                        byte[] storingByte = BitConverter.GetBytes(value16);
                        Array.Reverse(storingByte);
                        writer.WriteBytes(storingByte);
                        // Attempt to write the data to the device           
                        GattCommunicationStatus status =  await characteristic.WriteValueAsync(writer.DetachBuffer(), GattWriteOption.WriteWithoutResponse);
                        if (status == GattCommunicationStatus.Success)
                        {
                            var results = password_service.GetCharacteristics(ResultCharacteristicGUID)[0];
                            if (results != null)
                            {
                                results.ValueChanged += passwordCharacteristic_ValueChanged;
                                await results.WriteClientCharacteristicConfigurationDescriptorAsync(GattClientCharacteristicConfigurationDescriptorValue.Notify);
                                if (val == 1)
                                    this.Frame.Navigate(typeof(MenuPage), deviceId);
                            }
                            else
                            {
                                Debug.WriteLine("results was null");
                            }
                        }
                        else
                        {
                            Debug.WriteLine("status returned unsuccessful");
                        }    
                    }            
                }             
                else            
                {                
                    Debug.WriteLine("ERROR: WriteGattClienPassword could not obtain client password characteristic");  
                }
            }
        }

        private void BtnNum(object sender, RoutedEventArgs e)
        {
            Button val = (Button)sender;
            password += val.Content.ToString();
            if(Passcode.Text.Length<4)
                Passcode.Text += "*";
        }

        private void BtnClear(object sender, RoutedEventArgs e)
        {
            Sound.Play();
            if (Passcode.Text.Length > 0)
            { 
                password = "";
                Passcode.Text = ""; 
            }
        }

        void passwordCharacteristic_ValueChanged(GattCharacteristic sender, GattValueChangedEventArgs args)
        {
            byte[] Data = new byte[args.CharacteristicValue.Length];
            Windows.Storage.Streams.DataReader.FromBuffer(args.CharacteristicValue).ReadBytes(Data);
            val = convertData(Data);
            Debug.WriteLine(val);
        }

        int convertData(byte[] Data)
        {
            //The heartRateData received is a byte array with size 2. But the first position of the array is a not used flag
            //The heart rate data is in the second position of the heartRateData
            return ((int)Data[0]);
        }

        private void initialiseGattResources()
        {            
            // hook up the connection status change callback             
            mDevice.ConnectionStatusChanged += ConnectionChanged;  
            // get the service             
           password_service = mDevice.GetGattService(ConnectedCarServiceGUID);                       
        }

        async void ConnectionChanged(BluetoothLEDevice device, object obj) 
        {
            await Dispatcher.RunAsync(CoreDispatcherPriority.High, () =>
                {
                    if (device.ConnectionStatus == BluetoothConnectionStatus.Disconnected)
                        Debug.WriteLine("Conntection change to disconnected");
                    else
                        Debug.WriteLine("Connection change to connected");
                });
        }
    }
}
